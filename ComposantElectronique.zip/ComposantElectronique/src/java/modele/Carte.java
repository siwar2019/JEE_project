/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package modele;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author shyheb
 */
@Entity
@Table(name = "carte")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Carte.findAll", query = "SELECT c FROM Carte c"),
    @NamedQuery(name = "Carte.findByIdCarte", query = "SELECT c FROM Carte c WHERE c.idCarte = :idCarte"),
    @NamedQuery(name = "Carte.findByNomCarte", query = "SELECT c FROM Carte c WHERE c.nomCarte = :nomCarte"),
    @NamedQuery(name = "Carte.findByProcesseur", query = "SELECT c FROM Carte c WHERE c.processeur = :processeur"),
    @NamedQuery(name = "Carte.findByRam", query = "SELECT c FROM Carte c WHERE c.ram = :ram"),
    @NamedQuery(name = "Carte.findByCarteGraphique", query = "SELECT c FROM Carte c WHERE c.carteGraphique = :carteGraphique"),
    @NamedQuery(name = "Carte.findByCarteReseau", query = "SELECT c FROM Carte c WHERE c.carteReseau = :carteReseau"),
    @NamedQuery(name = "Carte.findByUsb", query = "SELECT c FROM Carte c WHERE c.usb = :usb"),
    @NamedQuery(name = "Carte.findByDisplayPort", query = "SELECT c FROM Carte c WHERE c.displayPort = :displayPort")})
public class Carte implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idCarte")
    private Integer idCarte;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "nomCarte")
    private String nomCarte;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "processeur")
    private String processeur;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "ram")
    private String ram;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "carteGraphique")
    private String carteGraphique;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "carteReseau")
    private String carteReseau;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "usb")
    private String usb;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "displayPort")
    private String displayPort;

    public Carte() {
    }

    public Carte(Integer idCarte) {
        this.idCarte = idCarte;
    }

    public Carte(Integer idCarte, String nomCarte, String processeur, String ram, String carteGraphique, String carteReseau, String usb, String displayPort) {
        this.idCarte = idCarte;
        this.nomCarte = nomCarte;
        this.processeur = processeur;
        this.ram = ram;
        this.carteGraphique = carteGraphique;
        this.carteReseau = carteReseau;
        this.usb = usb;
        this.displayPort = displayPort;
    }

    public Integer getIdCarte() {
        return idCarte;
    }

    public void setIdCarte(Integer idCarte) {
        this.idCarte = idCarte;
    }

    public String getNomCarte() {
        return nomCarte;
    }

    public void setNomCarte(String nomCarte) {
        this.nomCarte = nomCarte;
    }

    public String getProcesseur() {
        return processeur;
    }

    public void setProcesseur(String processeur) {
        this.processeur = processeur;
    }

    public String getRam() {
        return ram;
    }

    public void setRam(String ram) {
        this.ram = ram;
    }

    public String getCarteGraphique() {
        return carteGraphique;
    }

    public void setCarteGraphique(String carteGraphique) {
        this.carteGraphique = carteGraphique;
    }

    public String getCarteReseau() {
        return carteReseau;
    }

    public void setCarteReseau(String carteReseau) {
        this.carteReseau = carteReseau;
    }

    public String getUsb() {
        return usb;
    }

    public void setUsb(String usb) {
        this.usb = usb;
    }

    public String getDisplayPort() {
        return displayPort;
    }

    public void setDisplayPort(String displayPort) {
        this.displayPort = displayPort;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idCarte != null ? idCarte.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Carte)) {
            return false;
        }
        Carte other = (Carte) object;
        if ((this.idCarte == null && other.idCarte != null) || (this.idCarte != null && !this.idCarte.equals(other.idCarte))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "modele.Carte[ idCarte=" + idCarte + " ]";
    }
    
}
