/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package modele;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author shyheb
 */
@Entity
@Table(name = "capteur")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Capteur.findAll", query = "SELECT c FROM Capteur c"),
    @NamedQuery(name = "Capteur.findByIdCapteur", query = "SELECT c FROM Capteur c WHERE c.idCapteur = :idCapteur"),
    @NamedQuery(name = "Capteur.findByNom", query = "SELECT c FROM Capteur c WHERE c.nom = :nom"),
    @NamedQuery(name = "Capteur.findByIdCarte", query = "SELECT c FROM Capteur c WHERE c.idCarte = :idCarte")})
public class Capteur implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idCapteur")
    private Integer idCapteur;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "nom")
    private String nom;
    @Basic(optional = false)
    @NotNull
    @Column(name = "idCarte")
    private int idCarte;

    public Capteur() {
    }

    public Capteur(Integer idCapteur) {
        this.idCapteur = idCapteur;
    }

    public Capteur(Integer idCapteur, String nom, int idCarte) {
        this.idCapteur = idCapteur;
        this.nom = nom;
        this.idCarte = idCarte;
    }

    public Integer getIdCapteur() {
        return idCapteur;
    }

    public void setIdCapteur(Integer idCapteur) {
        this.idCapteur = idCapteur;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public int getIdCarte() {
        return idCarte;
    }

    public void setIdCarte(int idCarte) {
        this.idCarte = idCarte;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idCapteur != null ? idCapteur.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Capteur)) {
            return false;
        }
        Capteur other = (Capteur) object;
        if ((this.idCapteur == null && other.idCapteur != null) || (this.idCapteur != null && !this.idCapteur.equals(other.idCapteur))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "modele.Capteur[ idCapteur=" + idCapteur + " ]";
    }
    
}
