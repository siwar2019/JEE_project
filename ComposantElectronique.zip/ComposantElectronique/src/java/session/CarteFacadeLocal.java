/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package session;

import java.util.List;
import javax.ejb.Local;
import modele.Carte;

/**
 *
 * @author shyheb
 */
@Local
public interface CarteFacadeLocal {

    void create(Carte carte);

    void edit(Carte carte);

    void remove(Carte carte);

    Carte find(Object id);

    List<Carte> findAll();

    List<Carte> findRange(int[] range);

    int count();
    
}
