/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package session;

import java.util.List;
import javax.ejb.Local;
import modele.Capteur;

/**
 *
 * @author shyheb
 */
@Local
public interface CapteurFacadeLocal {

    void create(Capteur capteur);

    void edit(Capteur capteur);

    void remove(Capteur capteur);

    Capteur find(Object id);

    List<Capteur> findAll();

    List<Capteur> findRange(int[] range);

    int count();
    
}
