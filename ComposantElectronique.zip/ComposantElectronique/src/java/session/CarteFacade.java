/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package session;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import modele.Carte;

/**
 *
 * @author shyheb
 */
@Stateless
public class CarteFacade extends AbstractFacade<Carte> implements CarteFacadeLocal {
    @PersistenceContext(unitName = "ComposantElectroniquePU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public CarteFacade() {
        super(Carte.class);
    }
    
}
