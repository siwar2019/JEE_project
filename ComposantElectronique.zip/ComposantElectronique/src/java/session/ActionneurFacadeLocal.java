/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package session;

import java.util.List;
import javax.ejb.Local;
import modele.Actionneur;

/**
 *
 * @author shyheb
 */
@Local
public interface ActionneurFacadeLocal {

    void create(Actionneur actionneur);

    void edit(Actionneur actionneur);

    void remove(Actionneur actionneur);

    Actionneur find(Object id);

    List<Actionneur> findAll();

    List<Actionneur> findRange(int[] range);

    int count();
    
}
