/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package session;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import modele.Capteur;

/**
 *
 * @author shyheb
 */
@Stateless
public class CapteurFacade extends AbstractFacade<Capteur> implements CapteurFacadeLocal {
    @PersistenceContext(unitName = "ComposantElectroniquePU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public CapteurFacade() {
        super(Capteur.class);
    }
    
}
